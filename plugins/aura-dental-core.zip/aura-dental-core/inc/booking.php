<?php
/**
 * Booking form shortcode: [aura_booking_form title="..." light="1"]
 * Sends an email to the admin (filter `aura_dental_booking_recipient`).
 * ponytail: no DB storage, no spam service; add a honeypot only. Swap for CF7/WPForms if a buyer wants more.
 *
 * @package AURA_Dental_Core
 */

defined( 'ABSPATH' ) || exit;

function aura_dental_core_booking_form( $atts ) {
	$atts   = shortcode_atts( array( 'title' => __( 'Online booking', 'aura-dental-core' ), 'light' => '0' ), $atts, 'aura_booking_form' );
	$status = isset( $_GET['aura_booking'] ) ? sanitize_key( wp_unslash( $_GET['aura_booking'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$services = get_posts( array( 'post_type' => 'aura_service', 'numberposts' => 20, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	ob_start();
	?>
	<form class="aura-form<?php echo '1' === $atts['light'] ? ' aura-form--light' : ''; ?>" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<h3><?php echo esc_html( $atts['title'] ); ?></h3>
		<?php if ( 'sent' === $status ) : ?><p class="aura-form__notice"><?php esc_html_e( 'Thank you. Our coordinator will call you back shortly.', 'aura-dental-core' ); ?></p><?php endif; ?>
		<?php if ( 'error' === $status ) : ?><p class="aura-form__notice"><?php esc_html_e( 'Please fill in your name and phone number.', 'aura-dental-core' ); ?></p><?php endif; ?>
		<input type="hidden" name="action" value="aura_booking">
		<?php wp_nonce_field( 'aura_booking', 'aura_booking_nonce' ); ?>
		<input type="text" name="aura_website" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true">
		<input type="text" name="name" placeholder="<?php esc_attr_e( 'Your name', 'aura-dental-core' ); ?>" required>
		<input type="tel" name="phone" placeholder="<?php esc_attr_e( 'Phone number', 'aura-dental-core' ); ?>" required>
		<select name="service" aria-label="<?php esc_attr_e( 'Service', 'aura-dental-core' ); ?>">
			<option value=""><?php esc_html_e( 'Consultation (free)', 'aura-dental-core' ); ?></option>
			<?php foreach ( $services as $s ) : ?><option value="<?php echo esc_attr( $s->post_title ); ?>"><?php echo esc_html( $s->post_title ); ?></option><?php endforeach; ?>
		</select>
		<input type="text" name="note" placeholder="<?php esc_attr_e( 'Anything we should know?', 'aura-dental-core' ); ?>">
		<button type="submit" class="aura-btn"><?php esc_html_e( 'Send request', 'aura-dental-core' ); ?></button>
	</form>
	<?php
	return ob_get_clean();
}
add_shortcode( 'aura_booking_form', 'aura_dental_core_booking_form' );

function aura_dental_core_booking_submit() {
	$back = wp_get_referer() ? wp_get_referer() : home_url( '/' );
	if ( ! isset( $_POST['aura_booking_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['aura_booking_nonce'] ) ), 'aura_booking' ) || ! empty( $_POST['aura_website'] ) ) {
		wp_safe_redirect( $back );
		exit;
	}
	$name  = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$phone = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	if ( ! $name || ! $phone ) {
		wp_safe_redirect( add_query_arg( 'aura_booking', 'error', $back ) );
		exit;
	}
	$service = isset( $_POST['service'] ) ? sanitize_text_field( wp_unslash( $_POST['service'] ) ) : '';
	$note    = isset( $_POST['note'] ) ? sanitize_text_field( wp_unslash( $_POST['note'] ) ) : '';
	$to      = apply_filters( 'aura_dental_booking_recipient', get_option( 'admin_email' ) );
	$body    = sprintf( "%s: %s\n%s: %s\n%s: %s\n%s: %s", __( 'Name', 'aura-dental-core' ), $name, __( 'Phone', 'aura-dental-core' ), $phone, __( 'Service', 'aura-dental-core' ), $service, __( 'Note', 'aura-dental-core' ), $note );
	wp_mail( $to, sprintf( /* translators: %s: site name */ __( 'New booking request on %s', 'aura-dental-core' ), get_bloginfo( 'name' ) ), $body );
	wp_safe_redirect( add_query_arg( 'aura_booking', 'sent', remove_query_arg( 'aura_booking', $back ) ) . '#booking' );
	exit;
}
add_action( 'admin_post_nopriv_aura_booking', 'aura_dental_core_booking_submit' );
add_action( 'admin_post_aura_booking', 'aura_dental_core_booking_submit' );
