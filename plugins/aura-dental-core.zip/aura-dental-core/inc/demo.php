<?php
/**
 * Demo content importer: Appearance → Import AURA demo. Reads demo/content.json, sideloads demo/img/*.
 * Idempotent per slug (re-running updates existing posts).
 *
 * @package AURA_Dental_Core
 */

defined( 'ABSPATH' ) || exit;

function aura_dental_core_demo_menu() {
	add_theme_page( __( 'AURA demo import', 'aura-dental-core' ), __( 'Import AURA demo', 'aura-dental-core' ), 'manage_options', 'aura-demo', 'aura_dental_core_demo_page' );
}
add_action( 'admin_menu', 'aura_dental_core_demo_menu' );

function aura_dental_core_demo_page() {
	if ( isset( $_POST['aura_demo_nonce'] ) && wp_verify_nonce( sanitize_key( wp_unslash( $_POST['aura_demo_nonce'] ) ), 'aura_demo' ) ) {
		$n = aura_dental_core_import_demo();
		printf( '<div class="notice notice-success"><p>%s</p></div>', esc_html( sprintf( /* translators: %d: number of items */ __( 'Imported %d items.', 'aura-dental-core' ), $n ) ) );
	}
	echo '<div class="wrap"><h1>' . esc_html__( 'Import AURA demo content', 'aura-dental-core' ) . '</h1><p>' . esc_html__( 'Creates services, doctors, specialties, articles and the site pages with demo images. Safe to run again.', 'aura-dental-core' ) . '</p><form method="post">';
	wp_nonce_field( 'aura_demo', 'aura_demo_nonce' );
	submit_button( __( 'Import demo content', 'aura-dental-core' ) );
	echo '</form></div>';
}

function aura_dental_core_demo_image( $basename, $post_id ) {
	$dir = AURA_DENTAL_CORE_DIR . 'demo/img/';
	foreach ( array( 'png', 'jpg', 'jpeg', 'webp' ) as $ext ) {
		if ( file_exists( $dir . $basename . '.' . $ext ) ) {
			$file = $dir . $basename . '.' . $ext;
			break;
		}
	}
	if ( empty( $file ) ) {
		return 0;
	}
	$existing = get_posts( array( 'post_type' => 'attachment', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => '_aura_demo_src', 'meta_value' => $basename ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	if ( $existing ) {
		return (int) $existing[0];
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$tmp = wp_tempnam( basename( $file ) );
	copy( $file, $tmp );
	$id = media_handle_sideload( array( 'name' => basename( $file ), 'tmp_name' => $tmp ), $post_id );
	if ( is_wp_error( $id ) ) {
		return 0;
	}
	update_post_meta( $id, '_aura_demo_src', $basename );
	return (int) $id;
}

function aura_dental_core_demo_post( $type, $slug, $title, $content, $extra = array() ) {
	$slug  = sanitize_title( $slug );
	$found = get_posts( array( 'post_type' => $type, 'name' => $slug, 'numberposts' => 1, 'post_status' => 'any', 'fields' => 'ids' ) );
	$args  = array_merge( array( 'post_type' => $type, 'post_name' => $slug, 'post_title' => $title, 'post_content' => $content, 'post_status' => 'publish' ), $extra );
	if ( $found ) {
		$args['ID'] = $found[0];
		return (int) wp_update_post( $args );
	}
	return (int) wp_insert_post( $args );
}

function aura_dental_core_import_demo() {
	$json = AURA_DENTAL_CORE_DIR . 'demo/content.json';
	if ( ! file_exists( $json ) ) {
		return 0;
	}
	$data = json_decode( file_get_contents( $json ), true ); // phpcs:ignore WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown
	$n    = 0;
	$doctor_ids = array();
	foreach ( $data['specialties'] as $s ) {
		if ( ! term_exists( $s['slug'], 'aura_specialty' ) ) {
			wp_insert_term( $s['name'], 'aura_specialty', array( 'slug' => $s['slug'] ) );
		}
	}
	foreach ( $data['doctors'] as $i => $d ) {
		$id = aura_dental_core_demo_post( 'aura_doctor', $d['slug'], $d['name'], wp_kses_post( $d['bio'] ), array( 'post_excerpt' => $d['quote'], 'menu_order' => $i ) );
		$doctor_ids[ $d['slug'] ] = $id;
		foreach ( array( 'badge', 'credentials', 'years', 'years_label', 'quote', 'education', 'since', 'q1', 'a1', 'q2', 'a2', 'q3', 'a3' ) as $k ) {
			update_post_meta( $id, 'aura_' . $k, $d[ $k ] );
		}
		wp_set_object_terms( $id, $d['specialties'], 'aura_specialty' );
		$img = aura_dental_core_demo_image( $d['photo'], $id );
		if ( $img ) {
			set_post_thumbnail( $id, $img );
		}
		$n++;
	}
	foreach ( $data['services'] as $i => $s ) {
		$id = aura_dental_core_demo_post( 'aura_service', $s['slug'], $s['name'], wp_kses_post( $s['body'] ), array( 'post_excerpt' => $s['summary'], 'menu_order' => $i ) );
		foreach ( array( 'tagline', 'short', 'price', 'price_label', 'price_note', 'duration', 'visits', 'quote', 'quote_author' ) as $k ) {
			update_post_meta( $id, 'aura_' . $k, $s[ $k ] );
		}
		$ids = array();
		foreach ( $s['doctors'] as $ds ) {
			if ( isset( $doctor_ids[ $ds ] ) ) {
				$ids[] = $doctor_ids[ $ds ];
			}
		}
		update_post_meta( $id, 'aura_doctors', implode( ',', $ids ) );
		wp_set_object_terms( $id, $s['category'], 'aura_service_category' );
		$img = aura_dental_core_demo_image( $s['image'], $id );
		if ( $img ) {
			set_post_thumbnail( $id, $img );
		}
		$n++;
	}
	foreach ( $data['articles'] as $a ) {
		$id = aura_dental_core_demo_post( 'post', $a['slug'], $a['title'], wp_kses_post( $a['body'] ), array( 'post_excerpt' => $a['excerpt'] ) );
		update_post_meta( $id, 'aura_read_time', $a['read_time'] );
		update_post_meta( $id, 'aura_contents', $a['contents'] );
		update_post_meta( $id, 'aura_doctor_note', $a['doctor_note'] );
		foreach ( $a['stats'] as $k => $st ) {
			update_post_meta( $id, 'aura_stat' . ( $k + 1 ) . '_value', $st['value'] );
			update_post_meta( $id, 'aura_stat' . ( $k + 1 ) . '_label', $st['label'] );
		}
		update_post_meta( $id, 'aura_author_doctor', isset( $doctor_ids[ $a['author'] ] ) ? $doctor_ids[ $a['author'] ] : 0 );
		wp_set_object_terms( $id, $a['category'], 'category' );
		if ( $a['featured'] ) {
			stick_post( $id );
		}
		$img = aura_dental_core_demo_image( $a['cover'], $id );
		if ( $img ) {
			set_post_thumbnail( $id, $img );
		}
		$n++;
	}
	// Remove WordPress sample content so the demo matches the preview.
	foreach ( array( 'hello-world' => 'post', 'sample-page' => 'page' ) as $slug => $type ) {
		$old = get_posts( array( 'post_type' => $type, 'name' => $slug, 'numberposts' => 1, 'post_status' => 'any', 'fields' => 'ids' ) );
		if ( $old ) {
			wp_delete_post( $old[0], true );
		}
	}
	// Pages.
	$pages = array(
		'home'        => array( __( 'Home', 'aura-dental-core' ), 'page-home' ),
		'about'       => array( __( 'Clinic', 'aura-dental-core' ), 'page-about' ),
		'contact'     => array( __( 'Contact', 'aura-dental-core' ), 'page-contact' ),
		'first-visit' => array( __( 'Your First Visit', 'aura-dental-core' ), 'page-first-visit' ),
		'blog'        => array( __( 'Journal', 'aura-dental-core' ), '' ),
	);
	foreach ( $pages as $slug => $p ) {
		$id = aura_dental_core_demo_post( 'page', $slug, $p[0], '' );
		if ( $p[1] ) {
			update_post_meta( $id, '_wp_page_template', $p[1] );
		}
		$page_ids[ $slug ] = $id;
	}
	// Plain pages from content.json (legal pages linked from the footer).
	foreach ( (array) ( $data['pages'] ?? array() ) as $pg ) {
		aura_dental_core_demo_post( 'page', $pg['slug'], $pg['title'], wp_kses_post( $pg['content'] ) );
		$n++;
	}
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $page_ids['home'] );
	update_option( 'page_for_posts', $page_ids['blog'] );
	return $n;
}
