<?php
/**
 * Post types: Services, Doctors; taxonomy: Specialties.
 *
 * @package AURA_Dental_Core
 */

defined( 'ABSPATH' ) || exit;

function aura_dental_core_register_post_types() {
	register_post_type( 'aura_service', array(
		'labels'        => array(
			'name'          => __( 'Services', 'aura-dental-core' ),
			'singular_name' => __( 'Service', 'aura-dental-core' ),
			'add_new_item'  => __( 'Add New Service', 'aura-dental-core' ),
			'edit_item'     => __( 'Edit Service', 'aura-dental-core' ),
		),
		'public'        => true,
		'show_in_rest'  => true,
		'has_archive'   => true,
		'rewrite'       => array( 'slug' => 'services', 'with_front' => false ),
		'menu_icon'     => 'dashicons-heart',
		'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'page-attributes' ),
		'template'      => array( array( 'core/paragraph', array( 'placeholder' => __( 'Describe the treatment…', 'aura-dental-core' ) ) ) ),
	) );

	register_post_type( 'aura_doctor', array(
		'labels'        => array(
			'name'          => __( 'Doctors', 'aura-dental-core' ),
			'singular_name' => __( 'Doctor', 'aura-dental-core' ),
			'add_new_item'  => __( 'Add New Doctor', 'aura-dental-core' ),
			'edit_item'     => __( 'Edit Doctor', 'aura-dental-core' ),
		),
		'public'        => true,
		'show_in_rest'  => true,
		'has_archive'   => true,
		'rewrite'       => array( 'slug' => 'doctors', 'with_front' => false ),
		'menu_icon'     => 'dashicons-groups',
		'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'page-attributes' ),
	) );

	register_taxonomy( 'aura_specialty', array( 'aura_doctor', 'aura_service' ), array(
		'labels'       => array( 'name' => __( 'Specialties', 'aura-dental-core' ), 'singular_name' => __( 'Specialty', 'aura-dental-core' ) ),
		'public'       => true,
		'show_in_rest' => true,
		'hierarchical' => false,
		'rewrite'      => array( 'slug' => 'specialty' ),
	) );

	register_taxonomy( 'aura_service_category', 'aura_service', array(
		'labels'       => array( 'name' => __( 'Service Categories', 'aura-dental-core' ), 'singular_name' => __( 'Service Category', 'aura-dental-core' ) ),
		'public'       => true,
		'show_in_rest' => true,
		'hierarchical' => true,
		'rewrite'      => array( 'slug' => 'service-category' ),
	) );
}
add_action( 'init', 'aura_dental_core_register_post_types' );
