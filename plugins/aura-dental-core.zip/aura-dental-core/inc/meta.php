<?php
/**
 * Post meta, exposed to the block editor via Block Bindings (core/post-meta).
 * ponytail: no custom meta boxes; editors edit bound fields inline (WP 6.7+) or via the Custom Fields panel. Add meta boxes if buyers ask.
 *
 * @package AURA_Dental_Core
 */

defined( 'ABSPATH' ) || exit;

function aura_dental_core_meta_fields() {
	return array(
		'aura_service' => array(
			'tagline'      => __( 'Tagline', 'aura-dental-core' ),
			'short'        => __( 'Short description (lists)', 'aura-dental-core' ),
			'price'        => __( 'Price', 'aura-dental-core' ),
			'price_label'  => __( 'Price label', 'aura-dental-core' ),
			'price_note'   => __( 'Price note', 'aura-dental-core' ),
			'duration'     => __( 'Duration', 'aura-dental-core' ),
			'visits'       => __( 'Visits', 'aura-dental-core' ),
			'quote'        => __( 'Quote', 'aura-dental-core' ),
			'quote_author' => __( 'Quote author', 'aura-dental-core' ),
			'doctors'      => __( 'Doctor IDs (comma-separated)', 'aura-dental-core' ),
		),
		'post'         => array(
			'read_time'     => __( 'Read time', 'aura-dental-core' ),
			'contents'      => __( 'Contents (one heading per line)', 'aura-dental-core' ),
			'doctor_note'   => __( 'Doctor note', 'aura-dental-core' ),
			'author_doctor' => __( 'Author doctor ID', 'aura-dental-core' ),
			'stat1_value'   => __( 'Stat 1 value', 'aura-dental-core' ),
			'stat1_label'   => __( 'Stat 1 label', 'aura-dental-core' ),
			'stat2_value'   => __( 'Stat 2 value', 'aura-dental-core' ),
			'stat2_label'   => __( 'Stat 2 label', 'aura-dental-core' ),
			'stat3_value'   => __( 'Stat 3 value', 'aura-dental-core' ),
			'stat3_label'   => __( 'Stat 3 label', 'aura-dental-core' ),
		),
		'aura_doctor'  => array(
			'badge'       => __( 'Badge', 'aura-dental-core' ),
			'credentials' => __( 'Credentials', 'aura-dental-core' ),
			'years'       => __( 'Years', 'aura-dental-core' ),
			'years_label' => __( 'Years label', 'aura-dental-core' ),
			'quote'       => __( 'Quote', 'aura-dental-core' ),
			'education'   => __( 'Education', 'aura-dental-core' ),
			'since'       => __( 'At the clinic since', 'aura-dental-core' ),
			'q1'          => __( 'Question 1', 'aura-dental-core' ),
			'a1'          => __( 'Answer 1', 'aura-dental-core' ),
			'q2'          => __( 'Question 2', 'aura-dental-core' ),
			'a2'          => __( 'Answer 2', 'aura-dental-core' ),
			'q3'          => __( 'Question 3', 'aura-dental-core' ),
			'a3'          => __( 'Answer 3', 'aura-dental-core' ),
		),
	);
}

function aura_dental_core_register_meta() {
	foreach ( aura_dental_core_meta_fields() as $post_type => $fields ) {
		foreach ( $fields as $key => $label ) {
			register_post_meta(
				$post_type,
				'aura_' . $key,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true,
					'sanitize_callback' => 'contents' === $key ? 'sanitize_textarea_field' : 'sanitize_text_field',
					'auth_callback'     => function () {
						return current_user_can( 'edit_posts' );
					},
					'label'             => $label,
				)
			);
		}
	}
}
add_action( 'init', 'aura_dental_core_register_meta' );
