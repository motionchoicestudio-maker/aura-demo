<?php
/**
 * Plugin Name: AURA Dental Core
 * Plugin URI: https://aura-dental.promak.design
 * Description: Services, Doctors and Specialties post types, meta fields and demo content for the AURA Dental theme.
 * Version: 1.0.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Author: Promak Design
 * Author URI: https://promak.design
 * License: GPL-2.0-or-later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: aura-dental-core
 *
 * @package AURA_Dental_Core
 */

defined( 'ABSPATH' ) || exit;

define( 'AURA_DENTAL_CORE_VERSION', '1.0.0' );
define( 'AURA_DENTAL_CORE_DIR', plugin_dir_path( __FILE__ ) );

final class AURA_Dental_Core {
	public static function init() {
		require AURA_DENTAL_CORE_DIR . 'inc/post-types.php';
		require AURA_DENTAL_CORE_DIR . 'inc/meta.php';
		require AURA_DENTAL_CORE_DIR . 'inc/booking.php';
		require AURA_DENTAL_CORE_DIR . 'inc/demo.php';
		load_plugin_textdomain( 'aura-dental-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}
}
add_action( 'plugins_loaded', array( 'AURA_Dental_Core', 'init' ) );

register_activation_hook( __FILE__, function () {
	require AURA_DENTAL_CORE_DIR . 'inc/post-types.php';
	aura_dental_core_register_post_types();
	flush_rewrite_rules();
} );
